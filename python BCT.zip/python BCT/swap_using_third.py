# Write a python program to swap two variable by using third variable????
'''
'''
a=10
b=20
print("Before swapping value of a =",a,"and b= ",b)
c=a#
a=b#20
b=c#10
print("After swapping value of a =",a,"and b= ",b)

# Write a python program to swap two variable without using third variable.

x=10
y=5
print("Before swapping value of x=",x,"and y= ",y)
x=x+y#10+5=15
y=x-y#15-5=10
x=x-y#15-10=5
print("After swapping value of x=",x,"and y= ",y)


# but now we learn python
p=20
q=10
print("Before swapping value of p=",p,"and q= ",q)
p,q=q,p
print("After swapping value of p=",p,"and q= ",q)






