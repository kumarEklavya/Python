# Write a python program to find the area of circle where radius is taking from the user?????
'''
area=pi*r*r
p=2*3.14*r

'''
r=float(input("Enter the radius of the circle:-"))
area=3.14*r*r
p=2*3.14*r
print("Area of the circle is:-",area)
print("perimeter of the circle is:-",p)
