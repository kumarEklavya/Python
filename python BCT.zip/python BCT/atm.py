# Atm program:-
ballance=5000
withdraw=int(input("Enter withdraw Amount:-"))#3000
if ballance>=withdraw:
    print("Transactions is successfull!!!!")
    ballance=ballance-withdraw
    print("Your available ballance is:-",ballance)
else:
    print("in suffiecent ballance!!!!!")
