# single line comments
# How to see output in python????
'''
multiline comments
print()
'''
print("This is python first class!!!!")

# Data:-
'''
What is Data????
Data is a collections of information.

There are two types of data????
1 primitive or primary data type.
int(0-9),char('a','A' etc),float(10.5),string('kolkata'),boolean(True,False) etc
2 Non-primitive or secondary data type.
list,set,tuple,dictionary

'''
# What is variable????
'''
Variable is a container which is used to store value.
'''
# How to decleare a variable in python????
'''
Dont's:- 1 Variable name cannot be start with special symbols(#,!,@,% etc) or Numbers(0-9).
Do's:- 1 Varaible name must be start with alphabets(a-z,A-Z) or underscore(_).

'''
name='Debjit'
print(name)

# How to check value of data in any variable????
'''
type()
'''
print(type(name))

phone=6295939450
print(phone)
print(type(phone))

avg=99.5
print(avg)
print(type(avg))









