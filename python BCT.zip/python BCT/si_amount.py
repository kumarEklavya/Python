# write a python program to find the simple interest,total amount where principle(p),rate of
# interest(r),time(t) is taking from the user.
'''
si=p*r*t/100
a=p+si
'''
p=int(input("Enter the principle:-"))
r=int(input("Enter the rate of interest:-"))
t=int(input("Enter the time:-"))
si=(p*r*t)/100
a=p+si
print("simple interest =",si,"and amount =",a)


