# If:-
'''
syntax:-
if condition:
    statement
'''
age=15
if age>=18:
    print("he is eligible for give vote!!!!!")

# if else:-
'''
syntax:-
if condition:
    statement
else:
    statement
'''
age=15
if age>=18:
    print("he is eligible for give vote!!!!!")
else:
    print("Wait for some years!!!!!")

