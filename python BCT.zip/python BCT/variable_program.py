# addition of two numbers:-
'''
20+30=50
v1+v2=v3
n1+n2=add
'''
n1=int(input("Enter first Number:-"))
n2=int(input("Enter Second Number"))
add=n1+n2#20+30=50
print("addition is",add)

# How to take input from the user in python????
'''
syntax:-
var_name=int(input("msg"))
'''
